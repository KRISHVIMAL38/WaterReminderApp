package com.example.waterreminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ReminderBroadcast extends BroadcastReceiver {
    String CHANNEL_ID="notifyme";
    int NOTIFICATION_ID=001;
    @Override
    public void onReceive(Context context, Intent intent) {
       NotificationCompat.Builder builder=new NotificationCompat.Builder(context,"notifyme")
               .setSmallIcon(R.drawable.ic_alarm)
               .setContentTitle("time to stay hydrated")
               .setContentText("Please drink The water")
               .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManagerCompat=NotificationManagerCompat.from(context);
        notificationManagerCompat.notify(NOTIFICATION_ID,builder.build());
    }
}
