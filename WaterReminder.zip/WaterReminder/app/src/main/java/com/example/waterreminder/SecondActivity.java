package com.example.waterreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Calendar;

public class SecondActivity extends AppCompatActivity {
    Button button;
    RadioButton simpleRadioButton;
    RadioButton simpleRadioButton1;
    RadioGroup radioGroup1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        createNotificationChannel();

        button=findViewById(R.id.button);
        simpleRadioButton=findViewById(R.id.simpleRadioButton);
        simpleRadioButton1=findViewById(R.id.simpleRadioButton1);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(SecondActivity.this, "Reminder Set! If You are Male U Must drink 13 cups of water and if u are a female u must drink 10 cups of water .You will Receive reminders for water", Toast.LENGTH_LONG).show();
                Intent intent=new Intent(SecondActivity.this,ReminderBroadcast.class);
                PendingIntent pendingIntent=PendingIntent.getBroadcast(SecondActivity.this,0,intent,0);
                AlarmManager alarmManager= (AlarmManager) getSystemService(ALARM_SERVICE);
                long time=System.currentTimeMillis();
                long tenSeconds=1000*10*3*60;
                Calendar cal = Calendar.getInstance();
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),tenSeconds,pendingIntent);

            }
        });

    }
    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            CharSequence name="Krushnat Malavekar";
            String description="This is the reminder";
            int importance= NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel=new NotificationChannel("notifyme",name,importance);
            channel.setDescription(description);

            NotificationManager notificationManager=getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

    }




}